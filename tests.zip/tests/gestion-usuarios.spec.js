// =============================================================================
// SCRIPT DE AUTOMATIZACIÓN - GESTIÓN DE USUARIOS
// URL: https://demo1.codigoveloz.lol/
// Herramienta: Playwright
// Versión: 4.0 - Selectores 100% confirmados desde HTML real
// =============================================================================

const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');

// =============================================================================
// ✅ LISTA DE USUARIOS A CREAR - ADMINISTRABLE
// Agrega o elimina objetos para gestionar qué usuarios procesa el script.
// "editName": nombre nuevo tras crear. null = no editar.
// =============================================================================
const USUARIOS_A_CREAR = [
  {
    id: 1,
    nombre: 'Ausberto Andres Vargas Silva',
    email: 'andsorepopcorns@gmail.com',
    password: 'P4ssw0rd2026',
    editName: 'Andres Vargas Silva',
  },
  // {
  //   id: 2,
  //   nombre: 'Maria Fernanda Lopez',
  //   email: 'mfernanda@gmail.com',
  //   password: 'SecurePass2026!',
  //   editName: null,
  // },
];

// =============================================================================
// CREDENCIALES ADMINISTRADOR
// =============================================================================
const ADMIN = {
  email: 'asd@gmail.com',
  password: '123123',
};

// =============================================================================
// REPORTE
// =============================================================================
const reporteEventos = [];

function registrar(tipo, descripcion, detalle = '', exito = true) {
  const timestamp = new Date().toLocaleTimeString('es-BO', { hour12: false });
  reporteEventos.push({ timestamp, tipo, descripcion, detalle, exito });
  const s = exito ? '✅' : '❌';
  console.log(`[${timestamp}] ${s} [${tipo}] ${descripcion}${detalle ? ' | ' + detalle : ''}`);
}

async function esperarLivewire(page, ms = 1200) {
  await page.waitForTimeout(ms);
}

// =============================================================================
// REPORTE HTML
// =============================================================================
function generarReporteHTML() {
  const ahora = new Date().toLocaleString('es-BO');
  const exitosos = reporteEventos.filter(e => e.exito).length;
  const fallidos = reporteEventos.filter(e => !e.exito).length;

  const filas = reporteEventos.map(e => `
    <tr class="${e.exito ? 'ok' : 'fail'}">
      <td>${e.timestamp}</td>
      <td><span class="badge badge-${e.tipo.toLowerCase().replace(/\s/g,'-')}">${e.tipo}</span></td>
      <td>${e.descripcion}</td>
      <td>${e.detalle || '—'}</td>
      <td class="estado">${e.exito ? '✅ OK' : '❌ ERROR'}</td>
    </tr>`).join('');

  const resumenUsuarios = USUARIOS_A_CREAR.map(u => `
    <tr>
      <td>#${u.id}</td>
      <td>${u.nombre}</td>
      <td>${u.email}</td>
      <td>${u.editName
        ? `<span class="badge badge-edicion">Editado → ${u.editName}</span>`
        : '<span class="badge badge-sin-editar">Sin edición</span>'}</td>
    </tr>`).join('');

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Reporte QA – Gestión de Usuarios</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Segoe UI',system-ui,sans-serif;background:#0f172a;color:#e2e8f0;padding:2rem;min-height:100vh}
    header{display:flex;align-items:center;gap:1rem;margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:1px solid #1e293b}
    .logo{width:48px;height:48px;background:linear-gradient(135deg,#6366f1,#a855f7);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem}
    h1{font-size:1.5rem;font-weight:700;color:#f8fafc}
    h1 span{font-size:0.85rem;font-weight:400;color:#94a3b8;display:block;margin-top:2px}
    .summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:1rem;margin-bottom:2rem}
    .card{background:#1e293b;border-radius:12px;padding:1.2rem 1.4rem;border:1px solid #334155}
    .card-label{font-size:0.75rem;color:#94a3b8;text-transform:uppercase;letter-spacing:0.05em}
    .card-value{font-size:2rem;font-weight:700;margin-top:0.3rem}
    .card-value.green{color:#4ade80}.card-value.red{color:#f87171}.card-value.blue{color:#60a5fa}.card-value.purple{color:#c084fc}
    h2{font-size:1rem;font-weight:600;color:#cbd5e1;margin-bottom:1rem;display:flex;align-items:center;gap:0.5rem}
    .section{margin-bottom:2rem}
    table{width:100%;border-collapse:collapse;font-size:0.85rem}
    thead tr{background:#0f172a}
    thead th{text-align:left;padding:0.7rem 1rem;color:#64748b;font-weight:600;text-transform:uppercase;font-size:0.72rem;letter-spacing:0.06em;border-bottom:1px solid #334155}
    tbody tr{border-bottom:1px solid #1e293b;transition:background 0.15s}
    tbody tr:hover{background:#1e293b}
    tbody td{padding:0.65rem 1rem;vertical-align:middle}
    tbody tr.fail td{color:#fca5a5}
    tbody tr.fail{background:rgba(239,68,68,0.05)}
    .badge{display:inline-block;padding:0.2rem 0.6rem;border-radius:999px;font-size:0.7rem;font-weight:600;text-transform:uppercase;letter-spacing:0.03em}
    .badge-login{background:#1e40af33;color:#93c5fd}
    .badge-logout{background:#44403c33;color:#d6d3d1}
    .badge-creación,.badge-creacion{background:#14532d33;color:#86efac}
    .badge-edición,.badge-edicion{background:#78350f33;color:#fcd34d}
    .badge-validación,.badge-validacion{background:#312e8133;color:#c4b5fd}
    .badge-error{background:#7f1d1d33;color:#fca5a5}
    .badge-sin-editar{background:#1e293b;color:#64748b}
    .estado{font-weight:700}
    td:first-child{color:#64748b;font-size:0.78rem;font-family:monospace}
    .table-wrapper{background:#1e293b;border-radius:12px;overflow:hidden;border:1px solid #334155}
    footer{margin-top:3rem;text-align:center;color:#475569;font-size:0.78rem;border-top:1px solid #1e293b;padding-top:1.5rem}
    footer strong{color:#64748b}
  </style>
</head>
<body>
  <header>
    <div class="logo">🧪</div>
    <div>
      <h1>Reporte de Automatización QA
        <span>URL: https://demo1.codigoveloz.lol/ &nbsp;|&nbsp; Generado: ${ahora}</span>
      </h1>
    </div>
  </header>
  <div class="summary-grid">
    <div class="card"><div class="card-label">Total eventos</div><div class="card-value blue">${reporteEventos.length}</div></div>
    <div class="card"><div class="card-label">Exitosos</div><div class="card-value green">${exitosos}</div></div>
    <div class="card"><div class="card-label">Con error</div><div class="card-value ${fallidos > 0 ? 'red' : 'green'}">${fallidos}</div></div>
    <div class="card"><div class="card-label">Usuarios procesados</div><div class="card-value purple">${USUARIOS_A_CREAR.length}</div></div>
  </div>
  <div class="section">
    <h2>👥 Usuarios procesados</h2>
    <div class="table-wrapper">
      <table>
        <thead><tr><th>#</th><th>Nombre</th><th>Email</th><th>Edición</th></tr></thead>
        <tbody>${resumenUsuarios}</tbody>
      </table>
    </div>
  </div>
  <div class="section">
    <h2>📋 Log de ejecución</h2>
    <div class="table-wrapper">
      <table>
        <thead><tr><th>Hora</th><th>Tipo</th><th>Descripción</th><th>Detalle</th><th>Estado</th></tr></thead>
        <tbody>${filas}</tbody>
      </table>
    </div>
  </div>
  <footer>
    Playwright QA v4.0 &nbsp;·&nbsp;
    <strong>Admin:</strong> ${ADMIN.email} &nbsp;·&nbsp;
    <strong>Usuarios:</strong> ${USUARIOS_A_CREAR.length}
  </footer>
</body>
</html>`;
}

// =============================================================================
// PASO 0: LOGOUT (asegura sesión limpia antes del login)
// Selector confirmado: button[type="submit"] con texto "Cerrar sesión"
// =============================================================================
async function cerrarSesionSiActiva(page) {
  registrar('LOGOUT', 'Verificando estado de sesión');
  await page.goto('https://demo1.codigoveloz.lol/', { waitUntil: 'networkidle' });
  await esperarLivewire(page, 1000);

  const urlActual = page.url();

  // Si está en el login, no hay sesión activa
  if (urlActual.includes('login')) {
    registrar('LOGOUT', 'Sin sesión activa – directo a login');
    return;
  }

  // Hay sesión activa → hacer logout
  registrar('LOGOUT', 'Sesión activa detectada – cerrando sesión', urlActual);

  // Selector confirmado desde el HTML real de la app
  const btnLogout = page.locator('button[type="submit"]:has-text("Cerrar sesión")');
  await btnLogout.waitFor({ state: 'visible', timeout: 10000 });
  await btnLogout.click();
  await page.waitForLoadState('networkidle');
  await esperarLivewire(page, 1500);

  const urlPostLogout = page.url();
  const logoutOk = urlPostLogout.includes('login');
  registrar('LOGOUT', `Logout ${logoutOk ? 'exitoso ✔' : 'sin redirección'}`, urlPostLogout, logoutOk);
}

// =============================================================================
// PASO 1: LOGIN
// Selectores confirmados desde HTML real: NO usa wire:model (el login es Laravel
// estándar con _token hidden + button[type="submit"])
// =============================================================================
async function realizarLogin(page) {
  registrar('LOGIN', 'Navegando a /login');
  await page.goto('https://demo1.codigoveloz.lol/login', { waitUntil: 'networkidle' });
  await esperarLivewire(page, 1000);

  // Imprimir inputs disponibles para diagnóstico
  const inputs = await page.$$eval('input:not([type="hidden"])', els =>
    els.map(e => `[type=${e.type}] [name=${e.name}] [wire=${e.getAttribute('wire:model')}] [placeholder=${e.placeholder}]`)
  );
  console.log('  🔍 Inputs en /login:');
  inputs.forEach(i => console.log('     ', i));

  // ── Campo EMAIL ────────────────────────────────────────────────────────────
  // El formulario de login de Laravel/Livewire puede tener varias variantes:
  const selectoresEmail = [
    'input[name="email"]',
    'input[type="email"]',
    'input[wire\\:model="email"]',
    'input[id="email"]',
    'input[placeholder*="email" i]',
    'input[placeholder*="correo" i]',
    // Último recurso: primer input de texto visible
    'input:not([type="password"]):not([type="hidden"]):not([type="checkbox"]):not([type="radio"])',
  ];

  let emailSelector = null;
  for (const sel of selectoresEmail) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0) {
        await el.waitFor({ state: 'visible', timeout: 4000 });
        await el.fill(ADMIN.email);
        emailSelector = sel;
        registrar('LOGIN', 'Email ingresado', `selector: ${sel}`);
        break;
      }
    } catch (_) {}
  }
  if (!emailSelector) throw new Error('No se encontró el campo de email en /login');

  // ── Campo PASSWORD ─────────────────────────────────────────────────────────
  const selectoresPass = [
    'input[name="password"]',
    'input[type="password"]',
    'input[wire\\:model="password"]',
    'input[id="password"]',
    'input[placeholder*="contraseña" i]',
    'input[placeholder*="password" i]',
  ];

  let passSelector = null;
  for (const sel of selectoresPass) {
    try {
      const el = page.locator(sel).first();
      if (await el.count() > 0) {
        await el.waitFor({ state: 'visible', timeout: 4000 });
        await el.fill(ADMIN.password);
        passSelector = sel;
        registrar('LOGIN', 'Contraseña ingresada', `selector: ${sel}`);
        break;
      }
    } catch (_) {}
  }
  if (!passSelector) throw new Error('No se encontró el campo de password en /login');

  // ── Botón SUBMIT ───────────────────────────────────────────────────────────
  const selectoresSubmit = [
    'button[type="submit"]',
    'button:has-text("Iniciar")',
    'button:has-text("Ingresar")',
    'button:has-text("Login")',
    'button:has-text("Entrar")',
    'input[type="submit"]',
  ];

  let submitOk = false;
  for (const sel of selectoresSubmit) {
    try {
      const btn = page.locator(sel).first();
      if (await btn.count() > 0) {
        await btn.waitFor({ state: 'visible', timeout: 4000 });
        await btn.click();
        submitOk = true;
        registrar('LOGIN', 'Submit clickeado', `selector: ${sel}`);
        break;
      }
    } catch (_) {}
  }
  if (!submitOk) throw new Error('No se encontró el botón submit en /login');

  await page.waitForLoadState('networkidle');
  await esperarLivewire(page, 2000);

  const urlPostLogin = page.url();
  const loginOk = !urlPostLogin.includes('login');
  registrar('LOGIN', `Login ${loginOk ? 'exitoso ✔' : 'fallido ✖'}`, `URL: ${urlPostLogin}`, loginOk);

  if (!loginOk) throw new Error('Login fallido – credenciales incorrectas o formulario no encontrado');
}

// =============================================================================
// PASO 2: CREAR USUARIO
// Selectores 100% confirmados desde HTML real
// =============================================================================
async function crearUsuario(page, usuario) {
  registrar('CREACIÓN', `Creando usuario #${usuario.id}`, usuario.nombre);

  // ── Botón "Nuevo Usuario" — confirmado: button[wire:click="openCreate"] ────
  const btnNuevo = page.locator('button[wire\\:click="openCreate"]');
  await btnNuevo.waitFor({ state: 'visible', timeout: 15000 });
  await btnNuevo.click();
  await esperarLivewire(page, 1500);
  registrar('CREACIÓN', 'Modal abierto');

  // ── Nombre — confirmado: input[wire:model="name"] ─────────────────────────
  const campoNombre = page.locator('input[wire\\:model="name"]');
  await campoNombre.waitFor({ state: 'visible', timeout: 10000 });
  await campoNombre.fill(usuario.nombre);
  registrar('CREACIÓN', 'Nombre completado', usuario.nombre);

  // ── Email — confirmado: input[wire:model="email"] ─────────────────────────
  const campoEmail = page.locator('input[wire\\:model="email"]');
  await campoEmail.waitFor({ state: 'visible', timeout: 5000 });
  await campoEmail.fill(usuario.email);
  registrar('CREACIÓN', 'Email completado', usuario.email);

  // ── Password — confirmado: input[wire:model="password"] ───────────────────
  const campoPass = page.locator('input[wire\\:model="password"]');
  await campoPass.waitFor({ state: 'visible', timeout: 5000 });
  await campoPass.fill(usuario.password);
  registrar('CREACIÓN', 'Contraseña completada', '(oculta)');

  // ── Botón GUARDAR — confirmado: button[wire:click="save"] ─────────────────
  const btnSave = page.locator('button[wire\\:click="save"]');
  await btnSave.waitFor({ state: 'visible', timeout: 8000 });
  await btnSave.click();
  registrar('CREACIÓN', 'Botón "Crear Usuario" clickeado');

  await esperarLivewire(page, 2500);
  await page.waitForLoadState('networkidle');
  await esperarLivewire(page, 1000);

  // ── Validar usuario en la lista ────────────────────────────────────────────
  const enLista = await page.locator(`text=${usuario.email}`).isVisible().catch(() => false);
  registrar('VALIDACIÓN', `Usuario en lista: ${enLista ? 'SÍ ✔' : 'NO ✖'}`, usuario.email, enLista);
}

// =============================================================================
// PASO 3: EDITAR NOMBRE DE USUARIO
// Selectores confirmados: button[wire:click="openEdit(ID)"] con title="Editar"
// =============================================================================
async function editarNombreUsuario(page, usuario) {
  if (!usuario.editName) {
    registrar('EDICIÓN', `Sin edición para #${usuario.id}`, usuario.email);
    return;
  }

  registrar('EDICIÓN', `Editando #${usuario.id}`, `"${usuario.nombre}" → "${usuario.editName}"`);

  // ── Localizar fila del usuario por su email ────────────────────────────────
  const filaUsuario = page.locator(`tr:has-text("${usuario.email}")`).first();
  await filaUsuario.waitFor({ state: 'visible', timeout: 15000 });

  // ── Botón editar — confirmado: button con title="Editar" y wire:click="openEdit(ID)"
  // El ID es dinámico, pero title="Editar" es estable
  const btnEditar = filaUsuario.locator('button[title="Editar"]');
  await btnEditar.waitFor({ state: 'visible', timeout: 8000 });
  await btnEditar.click();
  await esperarLivewire(page, 1500);
  registrar('EDICIÓN', 'Modal de edición abierto');

  // ── Editar nombre — confirmado: input[wire:model="name"] ──────────────────
  const campoNombre = page.locator('input[wire\\:model="name"]');
  await campoNombre.waitFor({ state: 'visible', timeout: 10000 });
  await campoNombre.click({ clickCount: 3 }); // seleccionar todo
  await campoNombre.fill(usuario.editName);
  registrar('EDICIÓN', 'Nombre actualizado', usuario.editName);

  // ── Guardar — confirmado: button[wire:click="save"] ───────────────────────
  const btnSave = page.locator('button[wire\\:click="save"]');
  await btnSave.waitFor({ state: 'visible', timeout: 8000 });
  await btnSave.click();
  registrar('EDICIÓN', 'Cambios guardados');

  await esperarLivewire(page, 2500);
  await page.waitForLoadState('networkidle');
  await esperarLivewire(page, 1000);

  // ── Validar nombre actualizado en lista ────────────────────────────────────
  const visible = await page.locator(`text=${usuario.editName}`).isVisible().catch(() => false);
  registrar('VALIDACIÓN', `Nombre editado en lista: ${visible ? 'SÍ ✔' : 'NO ✖'}`, usuario.editName, visible);
}

// =============================================================================
// TEST PRINCIPAL
// =============================================================================
test('Gestión completa de usuarios – demo1.codigoveloz.lol', async ({ page }) => {

  console.log('\n' + '═'.repeat(60));
  console.log('  🧪 AUTOMATIZACIÓN QA - GESTIÓN DE USUARIOS v4.0');
  console.log('═'.repeat(60) + '\n');

  try {
    // ── 0. LOGOUT previo (garantiza sesión limpia) ─────────────────────────
    await cerrarSesionSiActiva(page);

    // ── 1. LOGIN ───────────────────────────────────────────────────────────
    await realizarLogin(page);

    // ── 2 y 3. PROCESAR LISTA ─────────────────────────────────────────────
    for (const usuario of USUARIOS_A_CREAR) {
      console.log(`\n${'─'.repeat(50)}`);
      console.log(`  👤 Usuario #${usuario.id}: ${usuario.nombre}`);
      console.log('─'.repeat(50));

      await crearUsuario(page, usuario);
      await editarNombreUsuario(page, usuario);
    }

    registrar('CREACIÓN', `✔ Total procesados: ${USUARIOS_A_CREAR.length}`);

  } catch (error) {
    registrar('ERROR', 'Error crítico', error.message, false);
    throw error;

  } finally {
    // ── REPORTE ────────────────────────────────────────────────────────────
    const baseDir = path.resolve(__dirname, '..');
    const reportePath = path.join(baseDir, 'reports', 'reporte-qa.html');
    fs.mkdirSync(path.dirname(reportePath), { recursive: true });
    fs.writeFileSync(reportePath, generarReporteHTML(), 'utf-8');
    console.log('\n' + '═'.repeat(60));
    console.log(`  📄 REPORTE: ${reportePath}`);
    console.log('═'.repeat(60) + '\n');
  }
});
